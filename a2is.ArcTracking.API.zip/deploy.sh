#!/bin/bash
# deploy.sh — Setup & deploy ARC Tracking API on RHEL 9
# dotnet publish -c $ENVIRONMENT -r linux-x64 --self-contained false -o ./publish
# sudo -E bash deploy.sh

set -e

# ─── CONFIG ───────────────────────────────────────────────────────────────────
ENVIRONMENT="Qualitycontrol"
APP_NAME="arc-tracking-api"
APP_DIR="/opt/$APP_NAME"
APP_USER="appuser"
APP_PORT="5000"
DLL_NAME="a2is.ArcTracking.API.dll"

# Wajib diisi sebelum menjalankan script
TRACGOOGLE_APIKEY="${TRACGOOGLE__ApiKey:-}"
DB_CONN_STRING="${DB_ConnectionString:-Server=172.16.94.74;Database=a2isAuthorizationDB;Persist Security Info = True;Integrated Security=False;User ID=itapp; Password=It5Fu#H0m317;}"
DB_PROVIDER="${DB_ProviderName:-System.Data.SqlClient}"
# ──────────────────────────────────────────────────────────────────────────────

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# Harus dijalankan sebagai root
[ "$EUID" -ne 0 ] && error "Jalankan script ini dengan sudo: sudo bash deploy.sh"

# TRACGOOGLE__ApiKey wajib ada
if [ -z "$TRACGOOGLE_APIKEY" ]; then
    error "Set env variable terlebih dahulu:\n  export TRACGOOGLE__ApiKey='your-api-key'\n  sudo -E bash deploy.sh"
fi

# ─── 1. Install .NET 8 Runtime ────────────────────────────────────────────────
info "Menginstall .NET 8 ASP.NET Core Runtime..."
if ! dotnet --list-runtimes 2>/dev/null | grep -q "Microsoft.AspNetCore.App 8"; then
    dnf install -y aspnetcore-runtime-8.0
else
    info ".NET 8 ASP.NET Core Runtime sudah terinstall, skip."
fi

# ─── 2. Buat user khusus ──────────────────────────────────────────────────────
info "Menyiapkan user '$APP_USER'..."
if ! id "$APP_USER" &>/dev/null; then
    useradd -r -s /sbin/nologin "$APP_USER"
fi

# ─── 3. Deploy file publish ───────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PUBLISH_DIR="$SCRIPT_DIR/publish"

[ ! -d "$PUBLISH_DIR" ] && error "Folder publish tidak ditemukan di: $PUBLISH_DIR\nJalankan dulu: dotnet publish -c $ENVIRONMENT -r linux-x64 --self-contained false -o ./publish"
[ ! -f "$PUBLISH_DIR/$DLL_NAME" ] && error "File $DLL_NAME tidak ditemukan di $PUBLISH_DIR"

info "Menyalin file ke $APP_DIR..."
mkdir -p "$APP_DIR"
cp -r "$PUBLISH_DIR"/. "$APP_DIR/"
chown -R "$APP_USER":"$APP_USER" "$APP_DIR"

# ─── 3b. Buat folder log ──────────────────────────────────────────────────────
info "Menyiapkan folder log..."
mkdir -p "/var/log/arc-tracking-api"
chown -R "$APP_USER":"$APP_USER" "/var/log/arc-tracking-api"

# ─── 4a. Buat environment file ────────────────────────────────────────────────
ENV_FILE="/etc/$APP_NAME.env"
info "Membuat environment file $ENV_FILE..."
cat > "$ENV_FILE" <<EOF
ASPNETCORE_ENVIRONMENT="$ENVIRONMENT"
ASPNETCORE_URLS="http://0.0.0.0:$APP_PORT"
TRACGOOGLE__ApiKey="$TRACGOOGLE_APIKEY"
ConnectionStrings__a2isAuthorizationDB__ConnectionString="$DB_CONN_STRING"
ConnectionStrings__a2isAuthorizationDB__ProviderName="$DB_PROVIDER"
EOF
chmod 600 "$ENV_FILE"

# ─── 4b. Buat systemd service ─────────────────────────────────────────────────
info "Membuat systemd service..."
cat > "/etc/systemd/system/$APP_NAME.service" <<EOF
[Unit]
Description=ARC Tracking API (.NET 8)
After=network.target

[Service]
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/dotnet $APP_DIR/$DLL_NAME
Restart=always
RestartSec=10
KillSignal=SIGINT
User=$APP_USER
EnvironmentFile=$ENV_FILE

[Install]
WantedBy=multi-user.target
EOF

# ─── 5. Enable & start service ────────────────────────────────────────────────
info "Mengaktifkan dan menjalankan service..."
systemctl daemon-reload
systemctl enable "$APP_NAME"
systemctl restart "$APP_NAME"

# ─── 6. Buka port di firewall ─────────────────────────────────────────────────
info "Membuka port $APP_PORT di firewall..."
if command -v firewall-cmd &>/dev/null && systemctl is-active --quiet firewalld; then
    firewall-cmd --permanent --add-port="$APP_PORT/tcp" &>/dev/null
    firewall-cmd --reload
else
    warn "firewalld tidak aktif, skip konfigurasi firewall."
fi

# ─── 7. Verifikasi ────────────────────────────────────────────────────────────
sleep 3
if systemctl is-active --quiet "$APP_NAME"; then
    info "Service '$APP_NAME' berjalan di port $APP_PORT"
    info "Cek status: sudo systemctl status $APP_NAME"
    info "Cek log   : sudo journalctl -u $APP_NAME -f"
else
    error "Service gagal start. Cek log: sudo journalctl -u $APP_NAME -n 50"
fi
